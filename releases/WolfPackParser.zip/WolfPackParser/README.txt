Wolf Pack EQ Parser — Quick Start
==================================

Step 1 (first time only — skip if Node.js 20+ is already installed)
  Double-click install-node.bat
  Windows will pop up a UAC prompt (asking for admin permission).  Click Yes.
  It will check for Node.js, install via winget if available, and fall back
  to a direct MSI download from nodejs.org if winget fails.

Step 2
  Extract this folder INSIDE your EverQuest install directory if you can
  (e.g. C:\TAKP\WolfPackParser\) — the parser will auto-detect it. Or extract
  anywhere and enter the path manually when prompted.

Step 3
  Double-click Parser.bat
  First-run prompts (press Enter at each unless you need to change it):
    * EQ path -- accept the auto-detected path
    * Bot URL -- press Enter for the default Railway endpoint
    * Agent token -- paste the value from /token in Discord
    * Startup preference -- pick [1] Run automatically for hands-off setup

  Subsequent launches: NO prompts.  The parser finds your saved settings
  automatically and goes straight to the live dashboard.

Live dashboard (while running)
  Press U  -- check GitHub for a parser update and auto-restart
  Press T  -- enter a new agent token (token rotation)
  Press I  -- show parser info / version / stats file path
  Press Ctrl+C  -- stop the parser

Auto-update
  Every launch the parser fetches the latest agent and start-logsync.ps1
  from GitHub.  Content-based comparison so any code change triggers an
  update (no missed bumps).  Throttled to once every 12 hours.
  Disable by adding "AutoUpdate": false to logsync.config.json.

Get a fresh upload token
  Run /token in any Wolf Pack EQ Discord channel (officer only).
  Press T in the dashboard and paste the value.
  Fallback: edit logsync.config.json directly if [T] doesn't prompt.

This release: v2.2.5
  - install-node.ps1: drops the exact version pin in winget so installs
    don't fail with "No version found matching: 20.19.1" when the winget
    catalog moves on. winget always grabs the current LTS now.
  - install-node.ps1: checks winget's exit code and falls through to MSI
    download from nodejs.org if winget fails — previously the script
    silently continued and reported a confusing "node not recognized" error.
  - install-node.ps1: forces --source winget to skip the msstore agreement
    prompt that some users hit on first install.
  - install-node.bat double-click is the supported entry point (UAC self-elevates)
  - Better EQ-folder auto-detect: also checks the parser's PARENT folder,
    so extracting WolfPackParser INSIDE your TAKP install just works.
  - Dashboard data fixes (log timestamps, session damage totals, dedupe).
  - ASCII-only dashboard glyphs (no boxes in cmd.exe).
  - AGENT_VERSION reads from package.json so the dashboard increments.
  - Auto-update compares file CONTENT rather than version strings.

If your parses ever look wrong, redownload WolfPackParser.zip from the
bot's announcement channel and re-extract.  The script will detect your
existing config and skip every prompt.
