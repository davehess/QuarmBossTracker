Wolf Pack EQ Parser — Quick Start
==================================

Step 1 (first time only — skip if Node.js 18+ is already installed)
  Double-click install-node.bat
  Windows will pop up a UAC prompt (asking for admin permission).  Click Yes.
  It will check for Node.js and install it if missing.

Step 2
  Extract this folder INSIDE your EverQuest install directory if you can
  (e.g. C:\TAKP\WolfPackParser\) — the parser will auto-detect it. Or extract
  anywhere and enter the path manually when prompted.

Step 3
  Double-click Parser.bat
  First-run prompts (press Enter at each unless you need to change it):
    * EQ path -- accept the auto-detected path
    * Bot URL -- press Enter for the default Railway endpoint
    * Agent token -- paste the value from /token in Discord
    * Startup preference -- pick [1] Run automatically for hands-off setup

  Subsequent launches: NO prompts.  The parser finds your saved settings
  automatically and goes straight to the live dashboard.

Live dashboard (while running)
  Press U  -- check GitHub for a parser update and auto-restart
  Press T  -- enter a new agent token (token rotation)
  Press I  -- show parser info / version / stats file path
  Press Ctrl+C  -- stop the parser

Auto-update
  Every launch the parser fetches the latest agent and start-logsync.ps1
  from GitHub.  Comparison is content-based (normalized for CRLF/LF), so
  any code change triggers an update.  Throttled to once every 12 hours.
  Disable by adding "AutoUpdate": false to logsync.config.json.

Get a fresh upload token
  Run /token in any Wolf Pack EQ Discord channel (officer only).
  Press T in the dashboard and paste the value.
  Fallback: edit logsync.config.json directly if [T] doesn't prompt.

This release: v2.2.4
  - install-node.bat is back in the zip — double-click to self-elevate
    via UAC (the .ps1 right-click 'Run as Administrator' option isn't
    available on all Windows installs).
  - Better EQ-folder auto-detect: also checks the parser's PARENT folder,
    so extracting WolfPackParser INSIDE your TAKP install just works.
  - Empty / invalid EQ path now re-prompts (up to 3 attempts) instead of
    silently cascading into a Join-Path crash deep in the wizard.
  - Defensive guards in Install-AsService and Install-Shortcut prevent
    broken scheduled tasks if the EQ path somehow makes it through empty.
  - Dashboard fixes:
      * Log timestamps now seed from file mtime, no more "?" for offline chars
      * "Damage done this session" shows actual totals + top contributors
      * Top damage rows dedupe by attacker (one row per player, their best hit)
      * ASCII-only dashboard chars so cmd.exe doesn't render boxes
  - AGENT_VERSION reads from package.json so the version actually increments.
  - Auto-update compares file CONTENT rather than version strings.

If your parses ever look wrong, redownload WolfPackParser.zip from the
bot's announcement channel and re-extract.  The script will detect your
existing config and skip every prompt.
