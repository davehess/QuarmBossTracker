Wolf Pack EQ Parser — Quick Start
==================================

Step 1 (first time only)
  Right-click install-node.ps1 -> Run as Administrator
  This checks whether Node.js is installed and installs it if not.
  If you already have Node.js 18+, skip this step.

Step 2
  Double-click Parser.bat
  First-run prompts (just press Enter at each unless you know better):
    * EQ path -- accept the auto-detected path (A:\EQ, C:\EQ, etc.)
    * Bot URL -- press Enter to use the default Railway endpoint
    * Agent token -- paste the value from /token in Discord
    * Startup preference -- pick [1] Run automatically for hands-off setup

  Subsequent launches: NO prompts.  The parser finds your saved settings
  automatically and goes straight to the live dashboard.

Live dashboard (while running)
  Press U  -- check GitHub for a parser update and auto-restart
  Press T  -- enter a new agent token (token rotation)
  Press I  -- show parser info / version / stats file path
  Press Ctrl+C  -- stop the parser

Auto-update
  Every launch the parser fetches the latest agent (index.js + package.json)
  AND the latest start-logsync.ps1 from GitHub.  Comparison is content-based
  with normalized line endings, so any code change triggers an update --
  not just version-string bumps.  Throttled to once every 12 hours.
  Disable by adding "AutoUpdate": false to logsync.config.json.

Get a fresh upload token
  Run /token in any Wolf Pack EQ Discord channel (officer only).
  Press T in the dashboard and paste the value.
  Fallback: edit logsync.config.json directly if [T] doesn't prompt.

This release: v2.2.2
  - Auto-update now compares file CONTENT (normalized for CRLF/LF) rather
    than relying on a version string in the code.  Bug fix: previously the
    version string was never bumped so auto-update silently no-op'd.
  - AGENT_VERSION is now derived from package.json instead of hardcoded,
    so the dashboard always shows the running build number.
  - start-logsync.ps1 self-updates from GitHub alongside the agent.
  - /who output is parsed and shipped to the bot so /parsestats embeds
    can label non-guildies / Zek members by class instead of "Unknown".
  - [T] keybind to rotate agent tokens without re-running setup.
  - Persistent pet leader map -- pet damage rolls into the owner across
    encounters.  Recognises /pet leader output.
  - Captures DOT spell damage attribution.
  - Live ANSI dashboard with Recent Parses, session/lifetime stats, etc.

If your parses ever look wrong, redownload WolfPackParser.zip from the
bot's announcement channel and re-extract.  The script will detect your
existing config in your EQ folder and skip every prompt.
