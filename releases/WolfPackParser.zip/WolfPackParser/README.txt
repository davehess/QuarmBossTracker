Wolf Pack EQ Parser — Quick Start
==================================

Step 1 (first time only)
  Right-click install-node.ps1 → Run as Administrator
  Checks for Node.js and installs it automatically if needed.
  Skip if you already have Node.js 18 or newer.

Step 2
  Double-click Parser.bat
  First run: finds your EQ directory and asks how you want it to start
  (auto on login / desktop shortcut / Start menu / manual).
  After setup it runs silently in the background.

What it does
  Watches your EQ log files and streams encounter data to the Wolf Pack
  Quarm Bot. DoTs, nukes, procs — every tick counted automatically.
  No more manual parse pasting.

Need help?
  Discord : discord.gg/rtzZNxxT3
  Download: tinyurl.com/WolfPackParse
