Wolf Pack EQ Parser — setup
============================

1. Double-click RUN-FIRST-for-Node.js.bat
   Approve the UAC prompt. The script installs Node.js 20 if you don't
   have it, or confirms you do and closes. One-time per machine.

2. Double-click Parser.bat
   First run: it auto-detects your EQ folder, asks for the bot URL
   (press Enter for the default), asks for your agent token (get this
   from /token in Discord), and offers a "Run automatically" option
   that installs a Windows scheduled task so the parser starts every
   time you log in.

After first run:
- Dashboard: http://localhost:7777 (live in-raid stats)
- Guild views: https://wolfpack.quest
- Get new versions: https://parser.wolfpack.quest

What gets uploaded:
- Boss-encounter combat events (damage, healing, tanking)
- Guild chat + raid chat (relayed to Discord channels)
- /who and /sll output to keep timers fresh
NEVER uploaded: tells, group chat, custom channels, officer chat.
All filtering is local before any network call.

Need help? Type /parsehelp in Discord.
