Wolf Pack EQ Parser — Quick Start
==================================

Step 1 (first time only)
  Right-click install-node.ps1 -> Run as Administrator
  This checks whether Node.js is installed and installs it if not.
  If you already have Node.js 18+, skip this step.

Step 2
  Double-click Parser.bat
  First run: it will locate your EQ directory and ask how you want
  it to start (auto on login / desktop shortcut / Start menu / manual).
  After that first setup it runs silently in the background whenever
  you log in.

What it does
  - Tails your EQ log files for combat events
  - Filters out tells, guild chat, group/raid chat, /say, /shout BEFORE upload
  - Posts compact JSON per-encounter to the Wolf Pack bot
  - Privacy: NO chat lines ever leave your machine, only combat numbers

Get a fresh upload token
  Run /token in any Wolf Pack EQ Discord channel (officer only).
  Paste it when Parser.bat asks.

This release: v2.1.9
  - Fixes DoT spell damage attribution ("X has taken N damage from your SPELL")
  - Fixes proc/spellshield multi-word defenders
  - Recognises "X died." in addition to "X dies." for encounter-end detection
  - Captures pet leader declarations so pet damage is attributed to the owner

If your parses ever look wrong, redownload WolfPackParser.zip from the
bot's announcement channel and re-extract to overwrite the old files.
