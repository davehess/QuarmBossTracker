Wolf Pack EQ Parser — Quick Start
==================================

Step 1 (first time only — skip if Node.js 20+ is already installed)
  Double-click install-node.bat (UAC will appear; click Yes).
  Tries winget, falls back to MSI download from nodejs.org, and if
  both fail it opens nodejs.org/download in your browser.

Step 2
  Extract WolfPackParser anywhere in or above your EverQuest install:
    C:\TAKP\WolfPackParser\                 (recommended)
    C:\Games\EQ\TAKP\WolfPackParser\        (works — walks up to find eqgame.exe)
    C:\Users\<You>\Downloads\<...>\WolfPackParser\  (works if EQ is anywhere upward)
  Or extract anywhere and type the EQ path manually when prompted.

Step 3
  Double-click Parser.bat
  First-run prompts (press Enter at each unless you need to change it):
    * EQ path -- accept the auto-detected path
    * Bot URL -- press Enter for the default Railway endpoint
    * Agent token -- paste the value from /token in Discord
    * Startup preference -- pick [1] Run automatically for hands-off setup

  Subsequent launches: NO prompts.  The parser finds your saved settings
  automatically and goes straight to the live dashboard.

Live dashboard (while running)
  Press U  -- check GitHub for a parser update and auto-restart
  Press T  -- enter a new agent token (token rotation)
  Press I  -- show parser info / version / stats file path
  Press Ctrl+C  -- stop the parser

Auto-update
  Every launch the parser fetches the latest agent (index.js +
  package.json) and start-logsync.ps1 from GitHub.  Content-based
  comparison so any code change triggers an update.  Files are written
  as UTF-8 without BOM (Node refused to load BOM-prefixed package.json).
  Throttled to once every 12 hours.  Disable by adding "AutoUpdate":
  false to logsync.config.json.

Get a fresh upload token
  Run /token in any Wolf Pack EQ Discord channel (officer only).
  Press T in the dashboard and paste the value.
  Fallback: edit logsync.config.json directly if [T] doesn't prompt.

This release: v2.2.7
  - FIX: auto-update wrote files with a UTF-8 BOM (PowerShell 5.1
    default), which caused Node to crash with ERR_INVALID_PACKAGE_CONFIG
    on package.json. All writes now use UTF8Encoding($false) via
    .NET WriteAllText -- raw bytes, no BOM.
  - SELF-HEAL: on every launch the script strips a BOM from any
    previously-corrupted index.js or package.json (idempotent).  Users
    affected by the old buggy update recover automatically next launch.
  - EQ folder auto-detect now WALKS UP from the script's folder up to
    5 levels looking for eqgame.exe or eqlog_*.txt files.  Catches
    nested installs like C:\Games\EQ\TAKP\WolfPackParser\.
  - install-node.ps1: drops winget version pin, falls back to MSI,
    auto-opens nodejs.org/download in browser if both fail.
  - install-node.bat is the supported entry point (UAC self-elevates).
  - Better EQ-folder auto-detect: walks up to 5 levels from the script.
  - Dashboard data fixes (log timestamps, session damage totals, dedupe).
  - ASCII-only dashboard glyphs (no boxes in cmd.exe).
  - AGENT_VERSION reads from package.json so the dashboard increments.
  - Auto-update compares file CONTENT rather than version strings.

If your parses ever look wrong, redownload WolfPackParser.zip from the
bot's announcement channel and re-extract.  The script will detect your
existing config and skip every prompt.

Recovery from BOM-corrupted auto-update (v2.2.6 bug)
  If Parser.bat crashes immediately with ERR_INVALID_PACKAGE_CONFIG:
  either (a) redownload WolfPackParser.zip and re-extract, or
  (b) double-click Parser.bat twice — first run downloads the fixed
  script, second run self-heals the BOM and launches Node.
