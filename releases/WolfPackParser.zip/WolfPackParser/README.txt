Wolf Pack EQ Parser — Quick Start
==================================

Step 1 (first time only)
  Right-click install-node.ps1 -> Run as Administrator
  This checks whether Node.js is installed and installs it if not.
  If you already have Node.js 18+, skip this step.

Step 2
  Double-click Parser.bat
  First-run prompts (just press Enter at each unless you know better):
    * EQ path -- accept the auto-detected path (A:\EQ, C:\EQ, etc.)
    * Bot URL -- press Enter to use the default Railway endpoint
    * Agent token -- paste the value from /token in Discord
    * Startup preference -- pick [1] Run automatically for hands-off setup

What it does
  - Tails your EQ log files for combat events
  - Filters out tells, guild chat, group/raid chat, /say, /shout BEFORE upload
  - Posts compact JSON per-encounter to the Wolf Pack bot
  - Privacy: NO chat lines ever leave your machine, only combat numbers

Get a fresh upload token
  Run /token in any Wolf Pack EQ Discord channel (officer only).
  Paste it when Parser.bat asks.

This release: v2.2.0
  - Captures DoT spell damage attribution ("X has taken N damage from your SPELL")
  - Fixes proc/spellshield multi-word defenders
  - Recognises "X died." in addition to "X dies." for encounter-end detection
  - Persistent pet leader map -- pet damage rolls into the owner across encounters
  - Re-running Parser.bat from any folder now reuses your saved settings
    automatically (no more re-typing the EQ path/Bot URL/token after each
    new zip download).

If your parses ever look wrong, redownload WolfPackParser.zip from the
bot's announcement channel and re-extract.  The script will detect your
existing config in your EQ folder and skip every prompt.
