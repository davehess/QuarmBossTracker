Wolf Pack EQ Parser — Quick Start
==================================

Step 1 (first time only — skip if Node.js 20+ is already installed)
  Double-click install-node.bat
  Windows will pop up a UAC prompt (asking for admin permission).  Click Yes.
  Tries winget, falls back to MSI download from nodejs.org, and if
  both fail it opens nodejs.org/download in your browser.

Step 2
  Extract this folder INSIDE your EverQuest install directory if you can
  (e.g. C:\TAKP\WolfPackParser\) — the parser will auto-detect by walking
  up from its own folder looking for eqgame.exe.

Step 3
  Double-click Parser.bat
  First-run prompts (press Enter at each unless you need to change it):
    * EQ path -- accept the auto-detected path
    * Bot URL -- press Enter for the default Railway endpoint
    * Agent token -- paste the value from /token in Discord
    * Startup preference -- pick [1] Run automatically for hands-off setup

  Subsequent launches: NO prompts.  The parser finds your saved settings
  automatically and goes straight to the live dashboard.

Live dashboard (while running)
  Press U  -- check GitHub for a parser update and auto-restart
  Press T  -- enter a new agent token (token rotation)
  Press I  -- show parser info / version / stats file path
  Press Ctrl+C  -- stop the parser

Auto-update
  Every launch the parser fetches the latest agent + start-logsync.ps1
  from GitHub.  Content-based comparison so any code change triggers an
  update.  Throttled to once every 12 hours.  Disable by adding
  "AutoUpdate": false to logsync.config.json.

Get a fresh upload token
  Run /token in any Wolf Pack EQ Discord channel (officer only).
  Press T in the dashboard and paste the value.

This release: v2.2.8
  - /who buffer now flushes to the bot every 5 seconds (when new data
    arrives) even without a combat encounter.  Previously /whois would
    return "no data yet" until the parser next killed something.
  - Server processes who_data BEFORE rejecting noise-encounter payloads,
    so who-only uploads are no longer silently dropped.
  - All previous fixes still in: BOM-free file writes, walk-up EQ folder
    detection, install-node browser fallback, dashboard data fixes.

If your parses ever look wrong, redownload WolfPackParser.zip from the
bot's announcement channel and re-extract.  The script will detect your
existing config and skip every prompt.
